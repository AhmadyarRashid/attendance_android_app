package pk.com.USC.IT_Department.GridItem;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import pk.com.USC.IT_Department.R;

public class dasboard_item extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dasboard_item);
    }
}
